import type { GenreId } from '../shared/types.ts';

export interface GenreMeta {
  id: GenreId;
  label: string;
  subtitle: string;
  imageUrl: string;
  accentLabel: string;
  premises: string[];
}

export const GENRES: Record<GenreId, GenreMeta> = {
  clockwork_mystery: {
    id: 'clockwork_mystery',
    label: 'Clockwork Mystery',
    subtitle: 'Gaslamp alleys, locked ateliers, and precision alibis.',
    imageUrl: '/src/assets/images/genre_clockwork_mystery_1795618846381.jpg',
    accentLabel: 'Mystery & Deduction',
    premises: [
      'At eleven minutes past midnight, every pendulum in the guildhall stopped except the pocket watch inside the victim’s coat.',
      'The horologist left three identical keys on the velvet counter and a note reading only: do not wind the fourth chime.',
      'Rain slicked the cobblestones outside the Bellman Archive as the courier realized the ledger pages had been rewritten overnight.',
    ],
  },
  starlight_odyssey: {
    id: 'starlight_odyssey',
    label: 'Starlight Odyssey',
    subtitle: 'Orbital observatories, quiet beacons, and distant horizons.',
    imageUrl: '/src/assets/images/genre_starlight_odyssey_1795618845767.jpg',
    accentLabel: 'Speculative & Orbit',
    premises: [
      'The glass dome of Observatory Nine was meant to watch dead moons, until an unscheduled lantern blinked back from the crescent horizon.',
      'Three archivist-pilots woke from cryo-drift forty years ahead of schedule to find a fresh mug of tea still warm on the navigation console.',
      'Every star chart aboard the Helios Meridian agreed on one impossible fact: the nearest relay station had moved overnight.',
    ],
  },
  verdant_folklore: {
    id: 'verdant_folklore',
    label: 'Verdant Folklore',
    subtitle: 'Mossy shrines, lantern paths, and old bargains.',
    imageUrl: '/src/assets/images/genre_verdant_folklore_1795618847235.jpg',
    accentLabel: 'Folklore & Fable',
    premises: [
      'Whoever lights the stone shrine at the fork in the cedar path must leave behind either a memory or a promise before dawn.',
      'The mapmaker swore the valley held only seven villages, yet at dusk an eighth lantern always floated above the fern ridge.',
      'When the paper lantern beside the moss arch flared blue instead of amber, the travelers knew the forest had recognized one of them.',
    ],
  },
  coastal_noir: {
    id: 'coastal_noir',
    label: 'Coastal Noir',
    subtitle: 'Sea fog, cliffside lighthouses, and unspoken debts.',
    imageUrl: '/src/assets/images/genre_coastal_noir_1795618847270.jpg',
    accentLabel: 'Maritime & Noir',
    premises: [
      'The lighthouse keeper at Cape Marrow hadn’t signed a harbor log in six winters, yet someone kept trimming the wick before every storm.',
      'Low tide uncovered the brass hull of a skiff nobody in town would claim, along with a waterproof satchel chained to the tiller.',
      'At five in the evening the fog swallowed the pier, leaving only the rhythmic sweep of the beacon and two sets of wet footprints on the steps.',
    ],
  },
};

export const GENRE_LIST: GenreMeta[] = [
  GENRES.clockwork_mystery,
  GENRES.starlight_odyssey,
  GENRES.verdant_folklore,
  GENRES.coastal_noir,
];
