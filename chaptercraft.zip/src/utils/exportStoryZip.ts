import JSZip from 'jszip';
import { GENRES } from '../data/genres.ts';
import type { StoryRoom } from '../shared/types.ts';

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function formatStoryMarkdown(room: StoryRoom): string {
  const genre = GENRES[room.genre];
  const authors = room.players.map((p) => p.name).join(', ');
  const totalWords = room.passages.reduce((sum, p) => sum + p.wordCount, 0);

  const lines: string[] = [
    `# ${room.title}`,
    '',
    `Genre: ${genre.label} | Mode: ${room.mode === 'relay' ? 'Relay Chronicle' : 'Forking Paths'} | Chapters: ${room.passages.length} | Words: ${totalWords}`,
    `Writers: ${authors}`,
    '',
    '## Opening Premise',
    '',
    room.premise,
    '',
    '---',
    '',
  ];

  for (const passage of room.passages) {
    lines.push(`## Chapter ${passage.chapterNumber}`);
    lines.push(`*Written by ${passage.authorName} · ${passage.wordCount} words*`);
    if (passage.constraintUsed) {
      lines.push(`> Prompt Fulfilled: ${passage.constraintUsed}`);
    }
    lines.push('');
    lines.push(passage.text);
    lines.push('');
    if (passage.alternates && passage.alternates.length > 0) {
      lines.push('### Alternate Paths Considered');
      for (const alt of passage.alternates) {
        lines.push(`- **${alt.authorName}** (${alt.votes} votes): ${alt.text}`);
      }
      lines.push('');
    }
  }

  return lines.join('\n');
}

function buildStandaloneHtml(room: StoryRoom): string {
  const genre = GENRES[room.genre];
  const authors = escapeHtml(room.players.map((p) => p.name).join(', '));
  const chaptersHtml = room.passages
    .map(
      (p) => `
      <article class="chapter">
        <div class="meta">Chapter ${p.chapterNumber} · Written by ${escapeHtml(p.authorName)} · ${p.wordCount} words</div>
        ${p.constraintUsed ? `<p class="prompt">Constraint fulfilled: ${escapeHtml(p.constraintUsed)}</p>` : ''}
        <p class="prose">${escapeHtml(p.text).replace(/\n/g, '<br />')}</p>
      </article>`
    )
    .join('\n');

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(room.title)} — Chaptercraft Edition</title>
  <style>
    body { font-family: Georgia, serif; background: #FAF9F6; color: #18181B; max-width: 720px; margin: 48px auto; padding: 0 24px; line-height: 1.75; }
    h1 { font-size: 2.25rem; margin-bottom: 0.4rem; }
    .sub { font-family: system-ui, sans-serif; font-size: 0.875rem; color: #52525B; margin-bottom: 2rem; }
    .premise { font-style: italic; padding: 1.25rem 1.5rem; background: #F4F4F5; border-radius: 8px; margin-bottom: 2.5rem; }
    .chapter { margin-bottom: 2.25rem; padding-bottom: 1.75rem; border-bottom: 1px solid #E4E4E7; }
    .meta { font-family: system-ui, sans-serif; font-size: 0.8rem; color: #71717A; margin-bottom: 0.6rem; }
    .prompt { font-family: system-ui, sans-serif; font-size: 0.8rem; color: #1E3A8A; margin-bottom: 0.6rem; }
    .prose { font-size: 1.075rem; margin: 0; }
  </style>
</head>
<body>
  <h1>${escapeHtml(room.title)}</h1>
  <div class="sub">${escapeHtml(genre.label)} · Room ${escapeHtml(room.code)} · Writers: ${authors}</div>
  <div class="premise">${escapeHtml(room.premise)}</div>
  ${chaptersHtml}
</body>
</html>`;
}

export async function downloadStoryZip(room: StoryRoom): Promise<void> {
  const zip = new JSZip();
  const safeSlug = room.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'story';

  zip.file(`${safeSlug}/manuscript.md`, formatStoryMarkdown(room));
  zip.file(`${safeSlug}/story-reader.html`, buildStandaloneHtml(room));
  zip.file(`${safeSlug}/chronicle.json`, JSON.stringify(room, null, 2));

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${safeSlug}-chronicle.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
