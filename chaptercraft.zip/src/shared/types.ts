export type GenreId =
  | 'clockwork_mystery'
  | 'starlight_odyssey'
  | 'verdant_folklore'
  | 'coastal_noir';

export type GameMode = 'relay' | 'branch';

export type GamePhase = 'LOBBY' | 'WRITING' | 'VOTING' | 'COMPLETE';

export interface ConstraintCard {
  id: string;
  category: 'Object' | 'Twist' | 'Style';
  text: string;
  bonusPoints: number;
}

export interface Player {
  id: string;
  name: string;
  seatOrder: number;
  score: number;
  wordsWritten: number;
  constraintsMet: number;
  connected: boolean;
  isHost: boolean;
  isLocalSeat?: boolean;
}

export interface AlternateDraft {
  id: string;
  authorId: string;
  authorName: string;
  text: string;
  wordCount: number;
  votes: number;
  constraintUsed?: string;
}

export interface Passage {
  id: string;
  chapterNumber: number;
  authorId: string;
  authorName: string;
  text: string;
  wordCount: number;
  createdAt: string;
  constraintUsed?: string;
  constraintBonus?: number;
  votes: number;
  reactions: {
    applause: number;
    bookmark: number;
  };
  alternates?: AlternateDraft[];
}

export interface BranchSubmission {
  id: string;
  authorId: string;
  authorName: string;
  text: string;
  wordCount: number;
  constraintUsed?: string;
  voterIds: string[];
  submittedAt: string;
}

export interface StoryRoom {
  code: string;
  title: string;
  genre: GenreId;
  mode: GameMode;
  maxChapters: number;
  turnSeconds: number;
  premise: string;
  phase: GamePhase;
  players: Player[];
  hostId: string;
  currentTurnIndex: number;
  turnDeadline: number | null;
  activeConstraints: Record<string, ConstraintCard>;
  constraintRerollsUsed: Record<string, boolean>;
  passages: Passage[];
  submissions: BranchSubmission[];
  typingPlayerIds: string[];
  localPassAndPlay: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface RoomSummary {
  code: string;
  title: string;
  genre: GenreId;
  mode: GameMode;
  phase: GamePhase;
  playerCount: number;
  chapterCount: number;
  maxChapters: number;
  localPassAndPlay: boolean;
  updatedAt: string;
}

export type ClientMessage =
  | {
      type: 'room:create';
      payload: {
        playerName: string;
        title: string;
        genre: GenreId;
        mode: GameMode;
        maxChapters: number;
        turnSeconds: number;
        premise: string;
        localPassAndPlay: boolean;
        localSeats?: string[];
      };
    }
  | {
      type: 'room:join';
      payload: {
        code: string;
        playerName: string;
        playerId?: string;
      };
    }
  | {
      type: 'room:leave';
      payload: {
        code: string;
        playerId: string;
      };
    }
  | {
      type: 'seat:add';
      payload: {
        code: string;
        playerId: string;
        seatName: string;
      };
    }
  | {
      type: 'game:start';
      payload: {
        code: string;
        playerId: string;
      };
    }
  | {
      type: 'turn:reroll_constraint';
      payload: {
        code: string;
        playerId: string;
        seatId?: string;
      };
    }
  | {
      type: 'turn:typing';
      payload: {
        code: string;
        playerId: string;
        isTyping: boolean;
      };
    }
  | {
      type: 'turn:submit';
      payload: {
        code: string;
        playerId: string;
        seatId?: string;
        text: string;
        claimedConstraint?: boolean;
      };
    }
  | {
      type: 'branch:vote';
      payload: {
        code: string;
        playerId: string;
        voterSeatId?: string;
        submissionId: string;
      };
    }
  | {
      type: 'passage:react';
      payload: {
        code: string;
        playerId: string;
        passageId: string;
        kind: 'applause' | 'bookmark';
      };
    }
  | {
      type: 'game:finish';
      payload: {
        code: string;
        playerId: string;
      };
    }
  | {
      type: 'game:restart';
      payload: {
        code: string;
        playerId: string;
        newPremise?: string;
      };
    };

export type ServerMessage =
  | {
      type: 'room:joined';
      payload: {
        room: StoryRoom;
        selfId: string;
      };
    }
  | {
      type: 'room:state';
      payload: {
        room: StoryRoom;
      };
    }
  | {
      type: 'room:error';
      payload: {
        message: string;
      };
    };

export const CONSTRAINT_DECK: ConstraintCard[] = [
  { id: 'c1', category: 'Object', text: 'Weave in a cracked brass compass that points to the nearest lie.', bonusPoints: 15 },
  { id: 'c2', category: 'Twist', text: 'Reveal that two characters already knew each other before tonight.', bonusPoints: 20 },
  { id: 'c3', category: 'Style', text: 'End your passage with an unanswered question.', bonusPoints: 10 },
  { id: 'c4', category: 'Object', text: 'Mention an unopened envelope sealed with blue wax.', bonusPoints: 15 },
  { id: 'c5', category: 'Twist', text: 'Have a supposed ally hesitate at a crucial doorway.', bonusPoints: 20 },
  { id: 'c6', category: 'Style', text: 'Include a sensory detail about rain, salt, or static.', bonusPoints: 10 },
  { id: 'c7', category: 'Object', text: 'Introduce a tarnished key that fits no visible lock.', bonusPoints: 15 },
  { id: 'c8', category: 'Twist', text: 'Shift the scene to an unexpected vantage point or rooftop.', bonusPoints: 15 },
  { id: 'c9', category: 'Style', text: 'Use a piece of overheard dialogue from a passing stranger.', bonusPoints: 15 },
  { id: 'c10', category: 'Object', text: 'Feature a handwritten margin note in a borrowed ledger.', bonusPoints: 15 },
  { id: 'c11', category: 'Twist', text: 'Something the group thought was lost turns up in plain sight.', bonusPoints: 20 },
  { id: 'c12', category: 'Style', text: 'Open your passage with a sudden sound that breaks the silence.', bonusPoints: 10 },
];
