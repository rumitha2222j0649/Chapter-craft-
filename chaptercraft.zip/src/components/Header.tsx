import React from 'react';

export type AppView = 'lobby' | 'game' | 'archive' | 'rules' | 'zip';

interface HeaderProps {
  activeView: AppView;
  hasActiveRoom: boolean;
  onNavigate: (view: AppView) => void;
  onOpenCreate: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  hasActiveRoom,
  onNavigate,
  onOpenCreate,
}) => {
  const navItems: { id: AppView; label: string }[] = [
    { id: 'lobby', label: hasActiveRoom ? 'Lobby' : 'Play' },
    ...(hasActiveRoom ? [{ id: 'game' as AppView, label: 'Active Table' }] : []),
    { id: 'archive', label: 'Archive' },
    { id: 'rules', label: 'Rules' },
    { id: 'zip', label: 'Project Zip' },
  ];

  return (
    <header className="sticky top-0 z-30 border-b border-zinc-200 bg-[#FAF9F6]/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1280px] items-center justify-between gap-8 px-6 py-4">
        <button
          type="button"
          onClick={() => onNavigate(hasActiveRoom ? 'game' : 'lobby')}
          className="font-display text-xl font-bold tracking-tight text-zinc-900 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-800 cursor-pointer"
        >
          Chaptercraft
        </button>

        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-zinc-600"
        >
          {navItems.slice(0, 5).map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`relative py-1 whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-800 ${
                  isActive
                    ? 'text-zinc-950 font-semibold underline decoration-blue-800 decoration-2 underline-offset-8'
                    : 'hover:text-zinc-950 hover:underline hover:decoration-zinc-300 hover:underline-offset-8'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenCreate}
            className="rounded-lg bg-blue-900 px-4 py-2 text-sm font-semibold text-white transition-colors duration-150 hover:bg-blue-800 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-900"
          >
            New Story
          </button>
        </div>
      </div>

      {/* Compact mobile nav row */}
      <nav
        aria-label="Mobile navigation"
        className="flex md:hidden items-center gap-5 overflow-x-auto border-t border-zinc-200/80 px-6 py-2 text-xs font-medium text-zinc-600"
      >
        {navItems.slice(0, 5).map((item) => {
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`whitespace-nowrap shrink-0 py-1 ${
                isActive ? 'text-blue-900 font-semibold' : 'text-zinc-600'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
