import React, { useState } from 'react';
import { BookOpen, Check, Copy, Download, RefreshCw } from 'lucide-react';
import { GENRES } from '../data/genres.ts';
import type { StoryRoom } from '../shared/types.ts';
import { downloadStoryZip, formatStoryMarkdown } from '../utils/exportStoryZip.ts';
import { GenreArtwork } from './GenreArtwork.tsx';

interface ArchiveViewProps {
  stories: StoryRoom[];
  loading: boolean;
  onRefresh: () => void;
  onStartStory: () => void;
}

export const ArchiveView: React.FC<ArchiveViewProps> = ({
  stories,
  loading,
  onRefresh,
  onStartStory,
}) => {
  const [selected, setSelected] = useState<StoryRoom | null>(null);
  const [copied, setCopied] = useState(false);

  const activeStory = selected || stories[0] || null;

  const handleCopy = async (story: StoryRoom) => {
    try {
      await navigator.clipboard.writeText(formatStoryMarkdown(story));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  return (
    <main className="mx-auto max-w-[1280px] px-6 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-zinc-200 pb-6">
        <div>
          <h1 className="font-display text-3xl font-semibold text-zinc-950">
            Completed Story Archive
          </h1>
          <p className="mt-1.5 text-sm text-zinc-600">
            Finished manuscripts preserved on the server. Read any edition or export it as a standalone zip bundle.
          </p>
        </div>
        <button
          type="button"
          onClick={onRefresh}
          disabled={loading}
          className="inline-flex items-center gap-2 rounded-lg border border-zinc-300 bg-white px-4 py-2 text-xs font-semibold text-zinc-800 transition-colors hover:bg-zinc-50 cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} aria-hidden="true" />
          Refresh Archive
        </button>
      </div>

      {stories.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-zinc-200 bg-white p-12 text-center">
          <BookOpen className="mx-auto h-8 w-8 text-zinc-400" aria-hidden="true" />
          <h2 className="font-display mt-3 text-xl font-semibold text-zinc-950">
            No completed manuscripts yet
          </h2>
          <p className="mx-auto mt-1.5 max-w-md text-sm text-zinc-600">
            Once a writing table finishes its final chapter or the host selects Conclude Story, the finished book appears here.
          </p>
          <button
            type="button"
            onClick={onStartStory}
            className="mt-5 rounded-lg bg-blue-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 cursor-pointer"
          >
            Write the First Story
          </button>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-12">
          {/* Archive List */}
          <div className="lg:col-span-4 space-y-3">
            {stories.map((story) => {
              const isSelected = activeStory?.code === story.code;
              const wordTotal = story.passages.reduce((s, p) => s + p.wordCount, 0);
              return (
                <button
                  key={story.code}
                  type="button"
                  onClick={() => setSelected(story)}
                  className={`w-full rounded-xl border p-4 text-left transition-colors cursor-pointer ${
                    isSelected
                      ? 'border-blue-900 bg-white'
                      : 'border-zinc-200 bg-white hover:border-zinc-400'
                  }`}
                >
                  <div className="text-xs text-zinc-500">
                    <span>{GENRES[story.genre].label}</span>
                    <span aria-hidden="true"> · </span>
                    <span className="font-mono tabular-nums">{story.passages.length} ch</span>
                    <span aria-hidden="true"> · </span>
                    <span className="font-mono tabular-nums">{wordTotal}w</span>
                  </div>
                  <h2 className="font-display mt-1 text-lg font-semibold text-zinc-950">
                    {story.title}
                  </h2>
                  <p className="mt-1 truncate text-xs text-zinc-500">
                    Writers: {story.players.map((p) => p.name).join(', ')}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Selected Story Reader */}
          {activeStory && (
            <article className="lg:col-span-8 overflow-hidden rounded-2xl border border-zinc-200 bg-white">
              <div className="relative h-44 w-full overflow-hidden bg-zinc-900">
                <GenreArtwork
                  genre={activeStory.genre}
                  title={activeStory.title}
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/40 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6 text-white">
                  <div className="text-xs text-zinc-300">
                    <span>{GENRES[activeStory.genre].label}</span>
                    <span aria-hidden="true"> · </span>
                    <span className="font-mono">ROOM {activeStory.code}</span>
                  </div>
                  <h2 className="font-display mt-1 text-2xl font-semibold">
                    {activeStory.title}
                  </h2>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 bg-zinc-50 px-6 py-4">
                <div className="text-xs text-zinc-600">
                  Co-authored by {activeStory.players.map((p) => p.name).join(', ')}
                </div>
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => void handleCopy(activeStory)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-300 bg-white px-3 py-1.5 text-xs font-semibold text-zinc-800 hover:bg-zinc-50 cursor-pointer"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-700" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? 'Copied' : 'Copy Markdown'}
                  </button>
                  <button
                    type="button"
                    onClick={() => void downloadStoryZip(activeStory)}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-blue-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    Export Story (.zip)
                  </button>
                </div>
              </div>

              <div className="p-6 sm:p-8 space-y-6">
                <p className="font-display italic text-zinc-700">
                  {activeStory.premise}
                </p>
                {activeStory.passages.map((p, i) => (
                  <section key={p.id} className="border-t border-zinc-200 pt-5">
                    <div className="text-xs text-zinc-500">
                      Chapter {p.chapterNumber} · {p.authorName} · {p.wordCount} words
                    </div>
                    <p
                      className={`font-display mt-2.5 max-w-[70ch] whitespace-pre-line text-[17px] leading-[1.75] text-zinc-900 ${
                        i === 0 ? 'drop-cap' : ''
                      }`}
                    >
                      {p.text}
                    </p>
                  </section>
                ))}
              </div>
            </article>
          )}
        </div>
      )}
    </main>
  );
};
