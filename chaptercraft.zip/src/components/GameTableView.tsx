import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bookmark,
  Check,
  ChevronDown,
  ChevronUp,
  Copy,
  Download,
  Heart,
  LogOut,
  Plus,
  RefreshCw,
  RotateCcw,
  Send,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { GENRES } from '../data/genres.ts';
import type { StoryRoom } from '../shared/types.ts';
import { downloadStoryZip, formatStoryMarkdown } from '../utils/exportStoryZip.ts';
import { GenreArtwork } from './GenreArtwork.tsx';

interface GameTableViewProps {
  room: StoryRoom;
  selfId: string;
  wsConnected: boolean;
  muted: boolean;
  errorBanner: string | null;
  onDismissError: () => void;
  onToggleMute: () => void;
  onLeaveRoom: () => void;
  onStartGame: () => void;
  onAddLocalSeat: (name: string) => void;
  onRerollConstraint: (seatId?: string) => void;
  onTyping: (isTyping: boolean) => void;
  onSubmitPassage: (text: string, claimedConstraint: boolean, seatId?: string) => void;
  onCastVote: (submissionId: string, voterSeatId?: string) => void;
  onReactPassage: (passageId: string, kind: 'applause' | 'bookmark') => void;
  onFinishEarly: () => void;
  onRestartGame: (newPremise?: string) => void;
}

function formatTimeLeft(deadline: number | null, now: number): string {
  if (!deadline) return 'Untimed';
  const sec = Math.max(0, Math.ceil((deadline - now) / 1000));
  const mins = Math.floor(sec / 60);
  const rem = sec % 60;
  return `${mins}:${rem.toString().padStart(2, '0')}`;
}

export const GameTableView: React.FC<GameTableViewProps> = ({
  room,
  selfId,
  wsConnected,
  muted,
  errorBanner,
  onDismissError,
  onToggleMute,
  onLeaveRoom,
  onStartGame,
  onAddLocalSeat,
  onRerollConstraint,
  onTyping,
  onSubmitPassage,
  onCastVote,
  onReactPassage,
  onFinishEarly,
  onRestartGame,
}) => {
  const [draft, setDraft] = useState('');
  const [claimedConstraint, setClaimedConstraint] = useState(false);
  const [newSeatName, setNewSeatName] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedMd, setCopiedMd] = useState(false);
  const [expandedAlternates, setExpandedAlternates] = useState<Record<string, boolean>>({});
  const [now, setNow] = useState(Date.now());
  const [selectedBranchSeatId, setSelectedBranchSeatId] = useState<string>(selfId);
  const [selectedVoterSeatId, setSelectedVoterSeatId] = useState<string>(selfId);
  const typingTimerRef = useRef<number | null>(null);

  const isHost = room.hostId === selfId;
  const genreMeta = GENRES[room.genre];
  const totalWords = useMemo(
    () => room.passages.reduce((acc, p) => acc + p.wordCount, 0),
    [room.passages]
  );

  // Tick timer display
  useEffect(() => {
    if (!room.turnDeadline) return;
    const id = window.setInterval(() => setNow(Date.now()), 500);
    return () => window.clearInterval(id);
  }, [room.turnDeadline]);

  // Keep local branch seat synced to an unsubmitted seat when in Pass & Play
  useEffect(() => {
    if (!room.localPassAndPlay) {
      setSelectedBranchSeatId(selfId);
      setSelectedVoterSeatId(selfId);
      return;
    }
    if (room.phase === 'WRITING' && room.mode === 'branch') {
      const nextUnsubmitted = room.players.find(
        (p) => !room.submissions.some((s) => s.authorId === p.id)
      );
      if (nextUnsubmitted) {
        setSelectedBranchSeatId(nextUnsubmitted.id);
      }
    }
    if (room.phase === 'VOTING') {
      const nextUnvoted = room.players.find(
        (p) => !room.submissions.some((s) => s.voterIds.includes(p.id))
      );
      if (nextUnvoted) {
        setSelectedVoterSeatId(nextUnvoted.id);
      }
    }
  }, [room.localPassAndPlay, room.phase, room.mode, room.players, room.submissions, selfId]);

  const activeRelayPlayer =
    room.mode === 'relay' && room.players.length > 0
      ? room.players[room.currentTurnIndex % room.players.length]
      : null;

  const effectiveWriterId =
    room.mode === 'relay'
      ? activeRelayPlayer?.id ?? selfId
      : room.localPassAndPlay
        ? selectedBranchSeatId
        : selfId;

  const canWriteRelay =
    room.phase === 'WRITING' &&
    room.mode === 'relay' &&
    activeRelayPlayer !== null &&
    (activeRelayPlayer.id === selfId || (room.localPassAndPlay && isHost));

  const alreadySubmittedBranch =
    room.mode === 'branch' &&
    room.submissions.some((s) => s.authorId === effectiveWriterId);

  const activeConstraint = room.activeConstraints[effectiveWriterId];
  const rerollUsed = Boolean(room.constraintRerollsUsed[effectiveWriterId]);

  const draftWordCount = useMemo(() => {
    const t = draft.trim();
    return t ? t.split(/\s+/).length : 0;
  }, [draft]);

  const handleDraftChange = (val: string) => {
    setDraft(val);
    if (room.phase === 'WRITING') {
      onTyping(true);
      if (typingTimerRef.current) window.clearTimeout(typingTimerRef.current);
      typingTimerRef.current = window.setTimeout(() => {
        onTyping(false);
      }, 1500);
    }
  };

  const handleSubmitDraft = (e: React.FormEvent) => {
    e.preventDefault();
    if (draft.trim().length < 10) return;
    onTyping(false);
    onSubmitPassage(
      draft.trim(),
      claimedConstraint,
      room.localPassAndPlay ? effectiveWriterId : undefined
    );
    setDraft('');
    setClaimedConstraint(false);
  };

  const handleCopyInvite = async () => {
    const shareUrl = `${window.location.origin}/?room=${room.code}`;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedCode(true);
      window.setTimeout(() => setCopiedCode(false), 2000);
    } catch {
      // Clipboard blocked in some embedded contexts
    }
  };

  const handleCopyMarkdown = async () => {
    try {
      await navigator.clipboard.writeText(formatStoryMarkdown(room));
      setCopiedMd(true);
      window.setTimeout(() => setCopiedMd(false), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const handleAddSeatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSeatName.trim()) return;
    onAddLocalSeat(newSeatName.trim());
    setNewSeatName('');
  };

  const sortedStandings = useMemo(
    () => [...room.players].sort((a, b) => b.score - a.score || b.wordsWritten - a.wordsWritten),
    [room.players]
  );

  const typingNames = room.typingPlayerIds
    .filter((id) => id !== selfId)
    .map((id) => room.players.find((p) => p.id === id)?.name)
    .filter(Boolean);

  return (
    <main className="mx-auto max-w-[1280px] px-6 py-8">
      {/* Room Utility Toolbar (below top bar) */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-200 pb-5">
        <div className="flex flex-wrap items-center gap-3 text-sm text-zinc-600">
          <button
            type="button"
            onClick={handleCopyInvite}
            className="inline-flex items-center gap-2 rounded-lg border border-zinc-300 bg-white px-3 py-1.5 font-mono text-xs font-semibold tracking-wider text-zinc-900 transition-colors hover:bg-zinc-50 cursor-pointer"
            title="Copy shareable table link"
          >
            <span>ROOM {room.code}</span>
            {copiedCode ? (
              <Check className="h-3.5 w-3.5 text-emerald-700" aria-hidden="true" />
            ) : (
              <Copy className="h-3.5 w-3.5 text-zinc-500" aria-hidden="true" />
            )}
          </button>
          <span aria-hidden="true">·</span>
          <span className="font-medium text-zinc-800">
            {room.mode === 'relay' ? 'Relay Chronicle' : 'Forking Paths'}
          </span>
          <span aria-hidden="true">·</span>
          <span className="font-mono text-xs tabular-nums">
            Chapter {Math.min(room.passages.length + (room.phase === 'COMPLETE' ? 0 : 1), room.maxChapters)} of {room.maxChapters}
          </span>
          <span aria-hidden="true">·</span>
          <span className="text-xs font-medium text-zinc-500">
            {wsConnected ? 'WebSocket Synced' : 'Reconnecting'}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? 'Unmute sound effects' : 'Mute sound effects'}
            className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-300 bg-white px-3 py-1.5 text-xs font-semibold text-zinc-700 transition-colors hover:bg-zinc-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
            <span>{muted ? 'Muted' : 'Sound On'}</span>
          </button>

          {isHost && room.phase !== 'COMPLETE' && room.passages.length > 0 && (
            <button
              type="button"
              onClick={onFinishEarly}
              className="rounded-lg border border-zinc-300 bg-white px-3 py-1.5 text-xs font-semibold text-zinc-800 transition-colors hover:bg-zinc-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Conclude Story
            </button>
          )}

          <button
            type="button"
            onClick={onLeaveRoom}
            className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-300 bg-white px-3 py-1.5 text-xs font-semibold text-zinc-700 transition-colors hover:bg-zinc-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
            Leave Table
          </button>
        </div>
      </div>

      {errorBanner && (
        <div
          role="alert"
          className="mt-5 flex items-center justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-900"
        >
          <span>{errorBanner}</span>
          <button
            type="button"
            onClick={onDismissError}
            className="text-xs font-semibold underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main 2-Column Tabletop Layout */}
      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-12">
        {/* Left/Center Manuscript & Active Play */}
        <div className="lg:col-span-8 space-y-8">
          {/* Illustrated Story Header */}
          <article className="overflow-hidden rounded-2xl border border-zinc-200 bg-white">
            <div className="relative h-48 sm:h-56 w-full overflow-hidden bg-zinc-900">
              <GenreArtwork genre={room.genre} title={room.title} className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/45 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6 text-white">
                <div className="text-xs font-medium text-zinc-300">
                  <span>{genreMeta.label}</span>
                  <span aria-hidden="true"> · </span>
                  <span className="font-mono tabular-nums">{totalWords} words</span>
                  <span aria-hidden="true"> · </span>
                  <span>{room.localPassAndPlay ? 'Pass & Play Table' : 'Live Multiplayer'}</span>
                </div>
                <h1 className="font-display mt-1.5 text-2xl font-semibold tracking-tight sm:text-3xl [text-wrap:balance]">
                  {room.title}
                </h1>
              </div>
            </div>

            {/* Opening Premise */}
            <div className="border-b border-zinc-200 bg-zinc-50/70 px-6 py-5 sm:px-8">
              <div className="text-xs font-semibold text-zinc-500">Opening Premise</div>
              <p className="font-display mt-1.5 max-w-[70ch] text-base italic leading-relaxed text-zinc-800">
                {room.premise}
              </p>
            </div>

            {/* Accumulated Chapters */}
            <div className="px-6 py-6 sm:px-8">
              {room.passages.length === 0 ? (
                <div className="py-6 text-center text-sm text-zinc-500">
                  {room.phase === 'LOBBY'
                    ? 'The first page is ready. Start the story when your writers are seated.'
                    : 'Waiting for Chapter 1 to be written.'}
                </div>
              ) : (
                <div className="divide-y divide-zinc-200/80">
                  {room.passages.map((passage, index) => {
                    const hasAlternates = Boolean(passage.alternates && passage.alternates.length > 0);
                    const isExpanded = Boolean(expandedAlternates[passage.id]);

                    return (
                      <section key={passage.id} id={`chapter-${passage.chapterNumber}`} className="py-6 first:pt-0 last:pb-0">
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-500">
                          <div>
                            <span className="font-semibold text-zinc-800">
                              Chapter {passage.chapterNumber}
                            </span>
                            <span aria-hidden="true"> · </span>
                            <span>Written by {passage.authorName}</span>
                            <span aria-hidden="true"> · </span>
                            <span className="font-mono tabular-nums">{passage.wordCount} words</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <button
                              type="button"
                              onClick={() => onReactPassage(passage.id, 'applause')}
                              className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-zinc-600 transition-colors hover:bg-zinc-100 hover:text-zinc-900 cursor-pointer"
                            >
                              <Heart className="h-3.5 w-3.5" aria-hidden="true" />
                              <span className="font-mono tabular-nums">{passage.reactions.applause}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => onReactPassage(passage.id, 'bookmark')}
                              className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-zinc-600 transition-colors hover:bg-zinc-100 hover:text-zinc-900 cursor-pointer"
                            >
                              <Bookmark className="h-3.5 w-3.5" aria-hidden="true" />
                              <span className="font-mono tabular-nums">{passage.reactions.bookmark}</span>
                            </button>
                          </div>
                        </div>

                        {passage.constraintUsed && (
                          <div className="mt-2.5 rounded-lg border border-blue-200/80 bg-blue-50/60 px-3.5 py-2 text-xs text-blue-950">
                            <span className="font-semibold">Constraint fulfilled (+{passage.constraintBonus} pts): </span>
                            <span>{passage.constraintUsed}</span>
                          </div>
                        )}

                        <p
                          className={`font-display mt-3.5 max-w-[70ch] whitespace-pre-line text-[17px] leading-[1.75] text-zinc-900 ${
                            index === 0 ? 'drop-cap' : ''
                          }`}
                        >
                          {passage.text}
                        </p>

                        {hasAlternates && (
                          <div className="mt-4">
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedAlternates((prev) => ({
                                  ...prev,
                                  [passage.id]: !prev[passage.id],
                                }))
                              }
                              className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-600 hover:text-zinc-950 cursor-pointer"
                            >
                              {isExpanded ? (
                                <ChevronUp className="h-3.5 w-3.5" aria-hidden="true" />
                              ) : (
                                <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
                              )}
                              <span>
                                View {passage.alternates!.length} unchosen{' '}
                                {passage.alternates!.length === 1 ? 'branch' : 'branches'}
                              </span>
                            </button>

                            {isExpanded && (
                              <div className="mt-3 space-y-3 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
                                {passage.alternates!.map((alt) => (
                                  <div key={alt.id} className="border-b border-zinc-200 pb-3 last:border-b-0 last:pb-0">
                                    <div className="text-xs text-zinc-500">
                                      <span>{alt.authorName}</span>
                                      <span aria-hidden="true"> · </span>
                                      <span className="font-mono tabular-nums">{alt.votes} votes</span>
                                    </div>
                                    <p className="mt-1 text-sm leading-relaxed text-zinc-700">
                                      {alt.text}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                      </section>
                    );
                  })}
                </div>
              )}
            </div>
          </article>

          {/* Phase Control Panel */}
          {room.phase === 'LOBBY' && (
            <section className="rounded-2xl border border-zinc-200 bg-white p-6 sm:p-8">
              <h2 className="font-display text-xl font-semibold text-zinc-950">
                Gathering Writers
              </h2>
              <p className="mt-1.5 text-sm text-zinc-600">
                Share room code <span className="font-mono font-semibold text-zinc-900">{room.code}</span> with collaborators, or add local seats for Pass &amp; Play.
              </p>

              {isHost && (
                <form onSubmit={handleAddSeatSubmit} className="mt-5 flex flex-wrap gap-2.5">
                  <input
                    type="text"
                    value={newSeatName}
                    onChange={(e) => setNewSeatName(e.target.value)}
                    placeholder="Add local seat writer name"
                    maxLength={32}
                    className="flex-1 min-w-[200px] rounded-lg border border-zinc-300 bg-[#FAF9F6] px-3.5 py-2 text-sm text-zinc-900 focus:border-blue-800 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-300 bg-white px-4 py-2 text-xs font-semibold text-zinc-800 hover:bg-zinc-50 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                    Add Local Seat
                  </button>
                </form>
              )}

              <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-zinc-200 pt-5">
                <div className="text-xs text-zinc-500">
                  <span>{room.players.length} writer{room.players.length === 1 ? '' : 's'} seated</span>
                  <span aria-hidden="true"> · </span>
                  <span>{room.maxChapters} chapters planned</span>
                </div>
                {isHost ? (
                  <button
                    type="button"
                    onClick={onStartGame}
                    className="rounded-lg bg-blue-900 px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 cursor-pointer"
                  >
                    Start Story
                  </button>
                ) : (
                  <span className="text-sm font-medium text-zinc-600">
                    Waiting for host to start the story...
                  </span>
                )}
              </div>
            </section>
          )}

          {/* WRITING PHASE */}
          {room.phase === 'WRITING' && (
            <section className="rounded-2xl border border-zinc-200 bg-white p-6 sm:p-8">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-200 pb-4">
                <div>
                  <h2 className="font-display text-xl font-semibold text-zinc-950">
                    {room.mode === 'relay'
                      ? canWriteRelay
                        ? room.localPassAndPlay
                          ? `Writing Turn: ${activeRelayPlayer?.name}`
                          : 'Your Turn to Write'
                        : `${activeRelayPlayer?.name} is Writing`
                      : 'Draft Next Branch'}
                  </h2>
                  <p className="mt-0.5 text-xs text-zinc-500">
                    {room.mode === 'relay'
                      ? `Chapter ${room.passages.length + 1} of ${room.maxChapters}`
                      : `${room.submissions.length} of ${room.players.length} drafts locked in`}
                  </p>
                </div>

                <div className="rounded-lg border border-zinc-200 bg-zinc-50 px-3.5 py-1.5 font-mono text-sm font-semibold text-zinc-900 tabular-nums">
                  {formatTimeLeft(room.turnDeadline, now)}
                </div>
              </div>

              {/* Seat Selector for Pass & Play in Branch Mode */}
              {room.mode === 'branch' && room.localPassAndPlay && isHost && (
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold text-zinc-600">Drafting seat:</span>
                  {room.players.map((p) => {
                    const submitted = room.submissions.some((s) => s.authorId === p.id);
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setSelectedBranchSeatId(p.id);
                          setDraft('');
                          setClaimedConstraint(false);
                        }}
                        className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                          selectedBranchSeatId === p.id
                            ? 'bg-blue-900 text-white'
                            : submitted
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                        }`}
                      >
                        {p.name} {submitted ? '(Locked)' : ''}
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Active Composer or Waiting View */}
              {(room.mode === 'relay' && !canWriteRelay) ||
              (room.mode === 'branch' && alreadySubmittedBranch) ? (
                <div className="mt-6 rounded-xl border border-zinc-200 bg-zinc-50 p-6 text-center">
                  <p className="text-sm font-medium text-zinc-800">
                    {room.mode === 'branch'
                      ? 'Your branch draft is locked in. Waiting for the remaining writers to submit before voting begins.'
                      : typingNames.length > 0
                        ? `${typingNames.join(', ')} is actively typing...`
                        : `Waiting for ${activeRelayPlayer?.name ?? 'the active writer'} to submit Chapter ${room.passages.length + 1}.`}
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmitDraft} className="mt-5 space-y-5">
                  {activeConstraint && (
                    <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="text-xs font-semibold text-amber-900">
                          <span>Optional Constraint Card ({activeConstraint.category})</span>
                          <span aria-hidden="true"> · </span>
                          <span className="font-mono tabular-nums">+{activeConstraint.bonusPoints} pts</span>
                        </div>
                        {!rerollUsed && (
                          <button
                            type="button"
                            onClick={() =>
                              onRerollConstraint(
                                room.localPassAndPlay ? effectiveWriterId : undefined
                              )
                            }
                            className="inline-flex items-center gap-1 text-xs font-semibold text-amber-900 hover:underline cursor-pointer"
                          >
                            <RefreshCw className="h-3 w-3" aria-hidden="true" />
                            Draw Replacement
                          </button>
                        )}
                      </div>
                      <p className="mt-1.5 text-sm font-medium text-zinc-900">
                        {activeConstraint.text}
                      </p>
                      <label className="mt-3 inline-flex items-center gap-2 text-xs font-medium text-zinc-800 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={claimedConstraint}
                          onChange={(e) => setClaimedConstraint(e.target.checked)}
                          className="h-4 w-4 rounded border-zinc-300 text-blue-900"
                        />
                        <span>I wove this constraint into my passage</span>
                      </label>
                    </div>
                  )}

                  <div>
                    <label htmlFor="passage-input" className="sr-only">
                      Write your story passage
                    </label>
                    <textarea
                      id="passage-input"
                      rows={5}
                      maxLength={2000}
                      value={draft}
                      onChange={(e) => handleDraftChange(e.target.value)}
                      placeholder="Continue the scene with vivid detail, dialogue, or a sudden turn..."
                      className="w-full rounded-xl border border-zinc-300 bg-[#FAF9F6] p-4 font-display text-base leading-relaxed text-zinc-900 placeholder:font-sans placeholder:text-sm placeholder:text-zinc-400 focus:border-blue-800 focus:outline-none"
                    />
                    <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-500">
                      <span className="font-mono tabular-nums">
                        {draftWordCount} words · {draft.length}/2000 chars
                      </span>
                      <span>Minimum 10 characters to submit</span>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={draft.trim().length < 10}
                      className="inline-flex items-center gap-2 rounded-lg bg-blue-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 disabled:cursor-not-allowed disabled:opacity-45 cursor-pointer"
                    >
                      <Send className="h-4 w-4" aria-hidden="true" />
                      {room.mode === 'relay' ? 'Publish Chapter' : 'Lock In Branch'}
                    </button>
                  </div>
                </form>
              )}
            </section>
          )}

          {/* VOTING PHASE (Forking Paths) */}
          {room.phase === 'VOTING' && (
            <section className="rounded-2xl border border-zinc-200 bg-white p-6 sm:p-8">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-200 pb-4">
                <div>
                  <h2 className="font-display text-xl font-semibold text-zinc-950">
                    Vote on Canon Chapter {room.passages.length + 1}
                  </h2>
                  <p className="mt-0.5 text-xs text-zinc-500">
                    Choose which submitted continuation becomes part of the permanent manuscript.
                  </p>
                </div>
                <div className="rounded-lg border border-zinc-200 bg-zinc-50 px-3.5 py-1.5 font-mono text-sm font-semibold text-zinc-900 tabular-nums">
                  {formatTimeLeft(room.turnDeadline, now)}
                </div>
              </div>

              {room.localPassAndPlay && isHost && (
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold text-zinc-600">Voting as:</span>
                  {room.players.map((p) => {
                    const voted = room.submissions.some((s) => s.voterIds.includes(p.id));
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setSelectedVoterSeatId(p.id)}
                        className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                          selectedVoterSeatId === p.id
                            ? 'bg-blue-900 text-white'
                            : voted
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                        }`}
                      >
                        {p.name} {voted ? '(Voted)' : ''}
                      </button>
                    );
                  })}
                </div>
              )}

              <div className="mt-6 space-y-4">
                {room.submissions.map((sub, idx) => {
                  const activeVoter = room.localPassAndPlay ? selectedVoterSeatId : selfId;
                  const votedForThis = sub.voterIds.includes(activeVoter);
                  return (
                    <div
                      key={sub.id}
                      className={`rounded-xl border p-5 transition-colors ${
                        votedForThis
                          ? 'border-blue-800 bg-blue-50/40'
                          : 'border-zinc-200 bg-[#FAF9F6]'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="text-xs text-zinc-500">
                          <span className="font-semibold text-zinc-800">Option {idx + 1}</span>
                          <span aria-hidden="true"> · </span>
                          <span className="font-mono tabular-nums">{sub.wordCount} words</span>
                          <span aria-hidden="true"> · </span>
                          <span className="font-mono tabular-nums">{sub.voterIds.length} votes</span>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            onCastVote(
                              sub.id,
                              room.localPassAndPlay ? selectedVoterSeatId : undefined
                            )
                          }
                          className={`rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                            votedForThis
                              ? 'bg-blue-900 text-white'
                              : 'border border-zinc-300 bg-white text-zinc-800 hover:bg-zinc-100'
                          }`}
                        >
                          {votedForThis ? 'Selected' : 'Cast Vote'}
                        </button>
                      </div>
                      <p className="font-display mt-3 text-base leading-relaxed text-zinc-900">
                        {sub.text}
                      </p>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {/* COMPLETE PHASE */}
          {room.phase === 'COMPLETE' && (
            <section className="rounded-2xl border border-zinc-200 bg-white p-6 sm:p-8">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold text-zinc-500">Manuscript Complete</p>
                  <h2 className="font-display mt-1 text-2xl font-semibold text-zinc-950">
                    Final Edition &amp; Standings
                  </h2>
                  <p className="mt-1 text-sm text-zinc-600">
                    Your story has been saved to the public Archive. Download the complete edition or start another round.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => void downloadStoryZip(room)}
                    className="inline-flex items-center gap-2 rounded-lg bg-blue-900 px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-blue-800 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    Export Story (.zip)
                  </button>
                  <button
                    type="button"
                    onClick={handleCopyMarkdown}
                    className="inline-flex items-center gap-2 rounded-lg border border-zinc-300 bg-white px-4 py-2.5 text-xs font-semibold text-zinc-800 transition-colors hover:bg-zinc-50 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {copiedMd ? <Check className="h-3.5 w-3.5 text-emerald-700" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedMd ? 'Copied Markdown' : 'Copy Markdown'}
                  </button>
                  {isHost && (
                    <button
                      type="button"
                      onClick={() => onRestartGame()}
                      className="inline-flex items-center gap-2 rounded-lg border border-zinc-300 bg-white px-4 py-2.5 text-xs font-semibold text-zinc-800 transition-colors hover:bg-zinc-50 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                      Play Again
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-6 overflow-x-auto rounded-xl border border-zinc-200">
                <table className="w-full border-collapse text-left text-sm">
                  <thead>
                    <tr className="border-b border-zinc-200 bg-zinc-50 text-xs font-semibold text-zinc-600">
                      <th className="px-4 py-3">Writer</th>
                      <th className="px-4 py-3 text-right">Words</th>
                      <th className="px-4 py-3 text-right">Constraints</th>
                      <th className="px-4 py-3 text-right">Score</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200">
                    {sortedStandings.map((p) => (
                      <tr key={p.id}>
                        <td className="px-4 py-3 font-medium text-zinc-900">{p.name}</td>
                        <td className="px-4 py-3 text-right font-mono text-xs text-zinc-700 tabular-nums">
                          {p.wordsWritten}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-xs text-zinc-700 tabular-nums">
                          {p.constraintsMet}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-xs font-semibold text-zinc-950 tabular-nums">
                          {p.score} pts
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}
        </div>

        {/* Right Sidebar: Writers, Standings & Chapter Index */}
        <aside className="lg:col-span-4 space-y-6">
          <div className="rounded-2xl border border-zinc-200 bg-white p-6">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold text-zinc-950">
                Writers at Table
              </h2>
              <span className="font-mono text-xs text-zinc-500 tabular-nums">
                {room.players.length} / 8
              </span>
            </div>

            <div className="mt-4 divide-y divide-zinc-200">
              {room.players.map((p) => {
                const isTurn =
                  room.phase === 'WRITING' &&
                  room.mode === 'relay' &&
                  activeRelayPlayer?.id === p.id;
                const isTyping = room.typingPlayerIds.includes(p.id);

                return (
                  <div key={p.id} className="flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="truncate text-sm font-semibold text-zinc-900">
                          {p.name}
                        </span>
                        {p.id === selfId && (
                          <span className="text-xs text-zinc-500">(You)</span>
                        )}
                      </div>
                      <div className="mt-0.5 text-xs text-zinc-500">
                        <span>{p.isHost ? 'Host' : p.isLocalSeat ? 'Local Seat' : 'Writer'}</span>
                        <span aria-hidden="true"> · </span>
                        <span>
                          {isTurn
                            ? isTyping
                              ? 'Typing now'
                              : 'Active Turn'
                            : p.connected || p.isLocalSeat
                              ? 'Seated'
                              : 'Offline'}
                        </span>
                      </div>
                    </div>
                    <div className="text-right font-mono text-xs font-semibold text-zinc-800 tabular-nums shrink-0">
                      {p.score} pts
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-white p-6">
            <h2 className="font-display text-lg font-semibold text-zinc-950">
              Chapter Outline
            </h2>
            {room.passages.length === 0 ? (
              <p className="mt-2 text-sm text-zinc-500">
                Chapters will appear here as they are written.
              </p>
            ) : (
              <ul className="mt-3 space-y-2 text-sm">
                {room.passages.map((p) => (
                  <li key={p.id}>
                    <a
                      href={`#chapter-${p.chapterNumber}`}
                      className="flex items-center justify-between rounded-lg px-2.5 py-1.5 text-zinc-700 transition-colors hover:bg-zinc-100 hover:text-zinc-950"
                    >
                      <span className="truncate">
                        Ch. {p.chapterNumber} · {p.authorName}
                      </span>
                      <span className="font-mono text-xs text-zinc-500 tabular-nums shrink-0">
                        {p.wordCount}w
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            )}

            {room.passages.length > 0 && (
              <button
                type="button"
                onClick={() => void downloadStoryZip(room)}
                className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg border border-zinc-300 bg-white px-4 py-2 text-xs font-semibold text-zinc-800 transition-colors hover:bg-zinc-50 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                Export Draft (.zip)
              </button>
            )}
          </div>
        </aside>
      </div>
    </main>
  );
};
