import React from 'react';

interface RulesViewProps {
  onOpenCreate: () => void;
}

export const RulesView: React.FC<RulesViewProps> = ({ onOpenCreate }) => {
  return (
    <main className="mx-auto max-w-[960px] px-6 py-12">
      <div className="border-b border-zinc-200 pb-6">
        <p className="text-xs font-semibold text-zinc-500">Tabletop Guide</p>
        <h1 className="font-display mt-1.5 text-3xl font-semibold text-zinc-950 sm:text-4xl">
          How to Play Chaptercraft
        </h1>
        <p className="mt-2 max-w-[65ch] text-base text-zinc-600">
          Two collaborative storytelling formats designed for live multiplayer rooms or single-screen Pass &amp; Play gatherings.
        </p>
      </div>

      <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-2">
        <section className="rounded-2xl border border-zinc-200 bg-white p-6">
          <h2 className="font-display text-xl font-semibold text-zinc-950">
            01. Relay Chronicle
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-zinc-600">
            Writers take turns in order extending a single continuous story. When it is your turn, read the latest chapter, check your optional Constraint Card, and write the next passage before the round clock reaches zero.
          </p>
          <ul className="mt-4 space-y-2 text-sm text-zinc-700">
            <li>• +20 points for every published chapter.</li>
            <li>• +10 to +20 bonus points when weaving in your Constraint Card.</li>
            <li>• Live typing indicators keep everyone in sync across browsers.</li>
          </ul>
        </section>

        <section className="rounded-2xl border border-zinc-200 bg-white p-6">
          <h2 className="font-display text-xl font-semibold text-zinc-950">
            02. Forking Paths
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-zinc-600">
            Every writer secretly drafts a competing continuation at the same time. Once all drafts are locked in (or the clock expires), the table reads every branch and votes on which timeline becomes canon.
          </p>
          <ul className="mt-4 space-y-2 text-sm text-zinc-700">
            <li>• +15 points per vote earned on your draft.</li>
            <li>• +25 bonus points when your branch wins the chapter vote.</li>
            <li>• Unchosen drafts stay attached inside the “Unchosen Branches” drawer.</li>
          </ul>
        </section>
      </div>

      <section className="mt-8 rounded-2xl border border-zinc-200 bg-white p-6 sm:p-8">
        <h2 className="font-display text-xl font-semibold text-zinc-950">
          03. Exporting Editions
        </h2>
        <p className="mt-2 max-w-[68ch] text-sm leading-relaxed text-zinc-600">
          Any finished or in-progress chronicle can be downloaded as a self-contained <span className="font-mono text-xs">.zip</span> archive containing a formatted Markdown manuscript, an offline HTML reader edition, and structured JSON data.
        </p>
        <div className="mt-6">
          <button
            type="button"
            onClick={onOpenCreate}
            className="rounded-lg bg-blue-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 cursor-pointer"
          >
            Open a New Story Table
          </button>
        </div>
      </section>
    </main>
  );
};
