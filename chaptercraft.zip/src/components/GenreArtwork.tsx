import React, { useState } from 'react';
import { BookOpen } from 'lucide-react';
import { GENRES } from '../data/genres.ts';
import type { GenreId } from '../shared/types.ts';

interface GenreArtworkProps {
  genre: GenreId;
  className?: string;
  title?: string;
}

export const GenreArtwork: React.FC<GenreArtworkProps> = ({
  genre,
  className = 'w-full h-full object-cover',
  title,
}) => {
  const [failed, setFailed] = useState(false);
  const meta = GENRES[genre];

  if (failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-800 via-slate-900 to-zinc-950 p-6 text-center text-zinc-100 ${className}`}
      >
        <BookOpen className="mb-3 h-8 w-8 text-zinc-300" aria-hidden="true" />
        <p className="font-display text-lg font-semibold">{title || meta.label}</p>
        <p className="mt-1 text-xs text-zinc-400">{meta.accentLabel}</p>
      </div>
    );
  }

  return (
    <img
      src={meta.imageUrl}
      alt={title ? `${title} — ${meta.label} cover artwork` : `${meta.label} cover artwork`}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
