import React, { useEffect, useState } from 'react';
import { RefreshCw, X } from 'lucide-react';
import { GENRES, GENRE_LIST } from '../data/genres.ts';
import type { GameMode, GenreId } from '../shared/types.ts';

export interface CreateRoomPayload {
  playerName: string;
  title: string;
  genre: GenreId;
  mode: GameMode;
  maxChapters: number;
  turnSeconds: number;
  premise: string;
  localPassAndPlay: boolean;
  localSeats: string[];
}

interface CreateStoryModalProps {
  open: boolean;
  initialGenre: GenreId;
  defaultPlayerName: string;
  onClose: () => void;
  onCreate: (payload: CreateRoomPayload) => void;
}

export const CreateStoryModal: React.FC<CreateStoryModalProps> = ({
  open,
  initialGenre,
  defaultPlayerName,
  onClose,
  onCreate,
}) => {
  const [title, setTitle] = useState('The Fourth Chime');
  const [playerName, setPlayerName] = useState(defaultPlayerName || 'Maya');
  const [genre, setGenre] = useState<GenreId>(initialGenre);
  const [mode, setMode] = useState<GameMode>('relay');
  const [localPassAndPlay, setLocalPassAndPlay] = useState(false);
  const [seatTwo, setSeatTwo] = useState('Julian');
  const [seatThree, setSeatThree] = useState('');
  const [maxChapters, setMaxChapters] = useState(6);
  const [turnSeconds, setTurnSeconds] = useState(90);
  const [premiseIndex, setPremiseIndex] = useState(0);
  const [premise, setPremise] = useState(GENRES[initialGenre].premises[0]);

  useEffect(() => {
    if (open) {
      setGenre(initialGenre);
      setPremiseIndex(0);
      setPremise(GENRES[initialGenre].premises[0]);
      if (defaultPlayerName) setPlayerName(defaultPlayerName);
    }
  }, [open, initialGenre, defaultPlayerName]);

  if (!open) return null;

  const handleGenreSelect = (nextGenre: GenreId) => {
    setGenre(nextGenre);
    setPremiseIndex(0);
    setPremise(GENRES[nextGenre].premises[0]);
  };

  const handleCyclePremise = () => {
    const list = GENRES[genre].premises;
    const nextIdx = (premiseIndex + 1) % list.length;
    setPremiseIndex(nextIdx);
    setPremise(list[nextIdx]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const localSeats = localPassAndPlay
      ? [seatTwo.trim(), seatThree.trim()].filter(Boolean)
      : [];
    onCreate({
      playerName: playerName.trim() || 'Host Writer',
      title: title.trim() || 'Untitled Chronicle',
      genre,
      mode,
      maxChapters,
      turnSeconds,
      premise: premise.trim() || GENRES[genre].premises[0],
      localPassAndPlay,
      localSeats,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/50 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="create-story-heading"
    >
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-zinc-200 bg-white p-6 sm:p-8 shadow-xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="create-story-heading" className="font-display text-2xl font-semibold text-zinc-950">
              Start a Collaborative Story
            </h2>
            <p className="mt-1 text-sm text-zinc-600">
              Configure your writing table, mode, and opening premise.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="rounded-lg p-2 text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="story-title" className="block text-xs font-semibold text-zinc-700">
                Story Title
              </label>
              <input
                id="story-title"
                type="text"
                required
                maxLength={80}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-zinc-300 bg-[#FAF9F6] px-3.5 py-2.5 text-sm text-zinc-900 focus:border-blue-800 focus:outline-none"
              />
            </div>
            <div>
              <label htmlFor="host-name" className="block text-xs font-semibold text-zinc-700">
                Your Pen Name
              </label>
              <input
                id="host-name"
                type="text"
                required
                maxLength={32}
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-zinc-300 bg-[#FAF9F6] px-3.5 py-2.5 text-sm text-zinc-900 focus:border-blue-800 focus:outline-none"
              />
            </div>
          </div>

          {/* Play Format */}
          <div>
            <span className="block text-xs font-semibold text-zinc-700">Table Format</span>
            <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg bg-zinc-100 p-1">
              <button
                type="button"
                onClick={() => setLocalPassAndPlay(false)}
                className={`rounded-md px-3 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                  !localPassAndPlay
                    ? 'bg-white text-zinc-950 shadow-sm'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Live Multiplayer Room
              </button>
              <button
                type="button"
                onClick={() => setLocalPassAndPlay(true)}
                className={`rounded-md px-3 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                  localPassAndPlay
                    ? 'bg-white text-zinc-950 shadow-sm'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Pass &amp; Play (Single Screen)
              </button>
            </div>
            <p className="mt-1.5 text-xs text-zinc-500">
              {localPassAndPlay
                ? 'Multiple writers take turns on this device; great for couch play or solo multi-perspective testing.'
                : 'Share a 6-character room code so friends can write together in real time from their own devices.'}
            </p>

            {localPassAndPlay && (
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <input
                  type="text"
                  value={seatTwo}
                  onChange={(e) => setSeatTwo(e.target.value)}
                  placeholder="Writer 2 name"
                  maxLength={32}
                  aria-label="Writer 2 name"
                  className="rounded-lg border border-zinc-300 bg-[#FAF9F6] px-3 py-2 text-sm text-zinc-900 focus:border-blue-800 focus:outline-none"
                />
                <input
                  type="text"
                  value={seatThree}
                  onChange={(e) => setSeatThree(e.target.value)}
                  placeholder="Writer 3 name (optional)"
                  maxLength={32}
                  aria-label="Writer 3 name"
                  className="rounded-lg border border-zinc-300 bg-[#FAF9F6] px-3 py-2 text-sm text-zinc-900 focus:border-blue-800 focus:outline-none"
                />
              </div>
            )}
          </div>

          {/* Game Mode */}
          <div>
            <span className="block text-xs font-semibold text-zinc-700">Game Mode</span>
            <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg bg-zinc-100 p-1">
              <button
                type="button"
                onClick={() => setMode('relay')}
                className={`rounded-md px-3 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                  mode === 'relay'
                    ? 'bg-white text-zinc-950 shadow-sm'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Relay Chronicle
              </button>
              <button
                type="button"
                onClick={() => setMode('branch')}
                className={`rounded-md px-3 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                  mode === 'branch'
                    ? 'bg-white text-zinc-950 shadow-sm'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Forking Paths
              </button>
            </div>
            <p className="mt-1.5 text-xs text-zinc-500">
              {mode === 'relay'
                ? 'Writers take sequential turns extending the manuscript while weaving in constraint cards.'
                : 'Everyone writes a competing continuation simultaneously, then the table votes on which path becomes canon.'}
            </p>
          </div>

          {/* Genre Picker */}
          <div>
            <span className="block text-xs font-semibold text-zinc-700">Setting</span>
            <div className="mt-2 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {GENRE_LIST.map((g) => (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => handleGenreSelect(g.id)}
                  className={`rounded-lg border px-3 py-2.5 text-left text-xs font-semibold transition-colors cursor-pointer ${
                    genre === g.id
                      ? 'border-blue-900 bg-blue-50/70 text-blue-950'
                      : 'border-zinc-200 bg-white text-zinc-700 hover:border-zinc-300'
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </div>

          {/* Chapters & Timer */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <span className="block text-xs font-semibold text-zinc-700">Target Length</span>
              <div className="mt-2 flex gap-1.5 rounded-lg bg-zinc-100 p-1">
                {[4, 6, 8, 12].map((count) => (
                  <button
                    key={count}
                    type="button"
                    onClick={() => setMaxChapters(count)}
                    className={`flex-1 rounded-md py-1.5 font-mono text-xs font-semibold tabular-nums transition-colors cursor-pointer ${
                      maxChapters === count
                        ? 'bg-white text-zinc-950 shadow-sm'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    {count} ch
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="block text-xs font-semibold text-zinc-700">Turn Timer</span>
              <div className="mt-2 flex gap-1.5 rounded-lg bg-zinc-100 p-1">
                {[
                  { val: 60, label: '60s' },
                  { val: 90, label: '90s' },
                  { val: 120, label: '2m' },
                  { val: 0, label: 'None' },
                ].map((opt) => (
                  <button
                    key={opt.val}
                    type="button"
                    onClick={() => setTurnSeconds(opt.val)}
                    className={`flex-1 rounded-md py-1.5 font-mono text-xs font-semibold tabular-nums transition-colors cursor-pointer ${
                      turnSeconds === opt.val
                        ? 'bg-white text-zinc-950 shadow-sm'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Opening Premise */}
          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="story-premise" className="block text-xs font-semibold text-zinc-700">
                Opening Premise
              </label>
              <button
                type="button"
                onClick={handleCyclePremise}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-900 hover:underline cursor-pointer"
              >
                <RefreshCw className="h-3 w-3" aria-hidden="true" />
                Cycle Prompt
              </button>
            </div>
            <textarea
              id="story-premise"
              rows={3}
              maxLength={480}
              value={premise}
              onChange={(e) => setPremise(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-zinc-300 bg-[#FAF9F6] px-3.5 py-2.5 text-sm leading-relaxed text-zinc-900 focus:border-blue-800 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-zinc-200 pt-5">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-zinc-300 bg-white px-4 py-2.5 text-sm font-semibold text-zinc-700 transition-colors hover:bg-zinc-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-blue-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 cursor-pointer"
            >
              Create Story Table
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
