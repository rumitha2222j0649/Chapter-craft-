import React, { useState } from 'react';
import { ArrowRight, RefreshCw, Users } from 'lucide-react';
import { GENRES, GENRE_LIST } from '../data/genres.ts';
import type { GenreId, RoomSummary } from '../shared/types.ts';
import { GenreArtwork } from './GenreArtwork.tsx';

interface TitleLobbyViewProps {
  rooms: RoomSummary[];
  loadingRooms: boolean;
  onRefreshRooms: () => void;
  onOpenCreate: (presetGenre?: GenreId) => void;
  onJoinRoom: (code: string, playerName: string) => void;
  defaultPlayerName: string;
}

export const TitleLobbyView: React.FC<TitleLobbyViewProps> = ({
  rooms,
  loadingRooms,
  onRefreshRooms,
  onOpenCreate,
  onJoinRoom,
  defaultPlayerName,
}) => {
  const [joinCode, setJoinCode] = useState('');
  const [penName, setPenName] = useState(defaultPlayerName);
  const [featuredGenre, setFeaturedGenre] = useState<GenreId>('clockwork_mystery');
  const [joinError, setJoinError] = useState('');

  const activeFeatured = GENRES[featuredGenre];

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedCode = joinCode.trim().toUpperCase();
    const cleanedName = penName.trim() || 'Guest Writer';
    if (cleanedCode.length < 4) {
      setJoinError('Enter a valid 6-character room code.');
      return;
    }
    setJoinError('');
    onJoinRoom(cleanedCode, cleanedName);
  };

  return (
    <main className="mx-auto max-w-[1280px] px-6 py-10 lg:py-14">
      {/* Split Hero */}
      <section className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
        <div className="flex flex-col justify-between lg:col-span-6">
          <div>
            <p className="text-sm font-medium text-zinc-500">
              Collaborative Fiction Tabletop · Real-Time &amp; Pass-and-Play
            </p>
            <h1 className="font-display mt-3 text-4xl font-semibold tracking-tight text-zinc-950 sm:text-5xl [text-wrap:balance]">
              Write living stories together, one chapter at a time.
            </h1>
            <p className="mt-5 max-w-[58ch] text-base leading-relaxed text-zinc-600">
              Open a writing table with friends in live multiplayer or pass one screen around the room. Draw story constraints, vote on branching plotlines, and export your finished manuscript as a standalone edition.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => onOpenCreate(featuredGenre)}
                className="inline-flex items-center gap-2 rounded-lg bg-blue-900 px-6 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-blue-800 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-900"
              >
                Start New Story
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>
              <a
                href="#open-tables"
                className="rounded-lg border border-zinc-300 bg-white px-5 py-3 text-sm font-semibold text-zinc-800 transition-colors duration-150 hover:border-zinc-400 hover:bg-zinc-50 whitespace-nowrap shrink-0"
              >
                Browse Open Tables
              </a>
            </div>
          </div>

          {/* Direct Room Code Join Bar */}
          <form
            onSubmit={handleJoinSubmit}
            className="mt-10 rounded-xl border border-zinc-200 bg-white p-5"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-sans text-sm font-semibold text-zinc-900">
                Join an existing table by code
              </h2>
              <span className="text-xs text-zinc-500">Live WebSocket Sync</span>
            </div>
            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-12">
              <input
                type="text"
                value={penName}
                onChange={(e) => setPenName(e.target.value)}
                placeholder="Your pen name"
                maxLength={32}
                aria-label="Your pen name"
                className="sm:col-span-5 rounded-lg border border-zinc-300 bg-[#FAF9F6] px-3.5 py-2.5 text-sm text-zinc-900 placeholder:text-zinc-400 focus:border-blue-800 focus:outline-none"
              />
              <input
                type="text"
                value={joinCode}
                onChange={(e) => {
                  setJoinCode(e.target.value.toUpperCase());
                  if (joinError) setJoinError('');
                }}
                placeholder="Room code (e.g. TALE42)"
                maxLength={8}
                aria-label="Room code"
                className="sm:col-span-4 rounded-lg border border-zinc-300 bg-[#FAF9F6] px-3.5 py-2.5 font-mono text-sm uppercase tracking-wider text-zinc-900 placeholder:font-sans placeholder:normal-case placeholder:tracking-normal placeholder:text-zinc-400 focus:border-blue-800 focus:outline-none"
              />
              <button
                type="submit"
                className="sm:col-span-3 rounded-lg bg-zinc-900 px-4 py-2.5 text-sm font-semibold text-white transition-colors duration-150 hover:bg-zinc-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Join Table
              </button>
            </div>
            {joinError && (
              <p className="mt-2 text-xs font-medium text-red-700" role="alert">
                {joinError}
              </p>
            )}
          </form>
        </div>

        {/* Right Hero Visual Container matching left height */}
        <div className="lg:col-span-6">
          <div className="relative h-full min-h-[340px] overflow-hidden rounded-2xl border border-zinc-200 bg-zinc-900">
            <GenreArtwork
              genre={featuredGenre}
              className="h-full w-full object-cover transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/35 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8 text-white">
              <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-zinc-300">
                <span>Featured Setting</span>
                <span aria-hidden="true">·</span>
                <span>{activeFeatured.label}</span>
              </div>
              <p className="font-display mt-2 text-lg leading-snug text-zinc-50 sm:text-xl">
                “{activeFeatured.premises[0]}”
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                {GENRE_LIST.map((g) => (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => setFeaturedGenre(g.id)}
                    className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                      featuredGenre === g.id
                        ? 'bg-white text-zinc-950'
                        : 'bg-zinc-900/70 text-zinc-200 hover:bg-zinc-800'
                    }`}
                  >
                    {g.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Genre Editions Strip */}
      <section className="mt-16 border-t border-zinc-200 pt-12">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-semibold text-zinc-950">
              Story Settings
            </h2>
            <p className="mt-1 text-sm text-zinc-600">
              Select a literary world to launch a Relay Chronicle or Forking Paths table.
            </p>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {GENRE_LIST.map((genre) => (
            <button
              key={genre.id}
              type="button"
              onClick={() => onOpenCreate(genre.id)}
              className="group flex flex-col overflow-hidden rounded-xl border border-zinc-200 bg-white text-left transition-colors duration-150 hover:border-zinc-400 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-800"
            >
              <div className="aspect-[4/3] w-full overflow-hidden bg-zinc-100">
                <GenreArtwork
                  genre={genre.id}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                />
              </div>
              <div className="flex flex-1 flex-col justify-between p-5">
                <div>
                  <div className="text-xs text-zinc-500">
                    <span>{genre.accentLabel}</span>
                    <span aria-hidden="true"> · </span>
                    <span>{genre.premises.length} prompts</span>
                  </div>
                  <h3 className="font-display mt-1.5 text-lg font-semibold text-zinc-950">
                    {genre.label}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-zinc-600">
                    {genre.subtitle}
                  </p>
                </div>
                <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-blue-900 group-hover:underline">
                  Create in this setting
                  <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Open Multiplayer Tables */}
      <section id="open-tables" className="mt-16 border-t border-zinc-200 pt-12">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl font-semibold text-zinc-950">
              Open Multiplayer Tables
            </h2>
            <p className="mt-1 text-sm text-zinc-600">
              Active story rooms hosted right now. Join any table or open a second browser tab to test live sync.
            </p>
          </div>
          <button
            type="button"
            onClick={onRefreshRooms}
            disabled={loadingRooms}
            className="inline-flex items-center gap-2 rounded-lg border border-zinc-300 bg-white px-4 py-2 text-xs font-semibold text-zinc-800 transition-colors duration-150 hover:bg-zinc-50 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw
              className={`h-3.5 w-3.5 ${loadingRooms ? 'animate-spin' : ''}`}
              aria-hidden="true"
            />
            Refresh Tables
          </button>
        </div>

        {rooms.length === 0 ? (
          <div className="mt-6 rounded-xl border border-zinc-200 bg-white p-8 text-center">
            <Users className="mx-auto h-7 w-7 text-zinc-400" aria-hidden="true" />
            <h3 className="font-display mt-3 text-lg font-semibold text-zinc-900">
              No public tables open yet
            </h3>
            <p className="mx-auto mt-1 max-w-md text-sm text-zinc-600">
              Start a new multiplayer story to generate a shareable room code, or launch a single-screen Pass &amp; Play session.
            </p>
            <button
              type="button"
              onClick={() => onOpenCreate()}
              className="mt-5 rounded-lg bg-blue-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 cursor-pointer"
            >
              Open First Table
            </button>
          </div>
        ) : (
          <div className="mt-6 overflow-x-auto rounded-xl border border-zinc-200 bg-white">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-zinc-200 bg-zinc-50/80 text-xs font-semibold text-zinc-600">
                  <th className="px-5 py-3.5">Room</th>
                  <th className="px-5 py-3.5">Story Title</th>
                  <th className="px-5 py-3.5">Mode &amp; Setting</th>
                  <th className="px-5 py-3.5">Writers</th>
                  <th className="px-5 py-3.5">Progress</th>
                  <th className="px-5 py-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                {rooms.map((room) => (
                  <tr key={room.code} className="hover:bg-zinc-50/60">
                    <td className="px-5 py-4 font-mono text-xs font-semibold tracking-wider text-zinc-900 tabular-nums">
                      {room.code}
                    </td>
                    <td className="px-5 py-4 font-medium text-zinc-950">
                      {room.title}
                    </td>
                    <td className="px-5 py-4 text-zinc-600">
                      <span>{GENRES[room.genre].label}</span>
                      <span aria-hidden="true"> · </span>
                      <span>{room.mode === 'relay' ? 'Relay Chronicle' : 'Forking Paths'}</span>
                    </td>
                    <td className="px-5 py-4 font-mono text-xs text-zinc-700 tabular-nums">
                      {room.playerCount} / 8
                    </td>
                    <td className="px-5 py-4 font-mono text-xs text-zinc-700 tabular-nums">
                      {room.chapterCount} / {room.maxChapters} ch · {room.phase}
                    </td>
                    <td className="px-5 py-4 text-right">
                      <button
                        type="button"
                        onClick={() => onJoinRoom(room.code, penName.trim() || 'Guest Writer')}
                        className="rounded-lg bg-zinc-900 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-zinc-800 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        Join Table
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
};
