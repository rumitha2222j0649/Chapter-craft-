import React, { useState } from 'react';
import { Check, Copy, Download, Package } from 'lucide-react';

export const ProjectZipView: React.FC = () => {
  const [downloading, setDownloading] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const oneLineCommand =
    'npm run build && zip -r chaptercraft-project-build.zip dist src server.ts index.html package.json tsconfig.json vite.config.ts metadata.json .env.example';

  const handleDownloadZip = async () => {
    setDownloading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/project-zip');
      if (!res.ok) {
        throw new Error('Failed to generate project zip archive.');
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'chaptercraft-project-build.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Download failed.');
    } finally {
      setDownloading(false);
    }
  };

  const handleCopyCommand = async () => {
    try {
      await navigator.clipboard.writeText(oneLineCommand);
      setCopiedCmd(true);
      window.setTimeout(() => setCopiedCmd(false), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  return (
    <main className="mx-auto max-w-[960px] px-6 py-12">
      <div className="border-b border-zinc-200 pb-6">
        <p className="text-xs font-semibold text-zinc-500">Project Distribution</p>
        <h1 className="font-display mt-1.5 text-3xl font-semibold text-zinc-950 sm:text-4xl">
          Download Built Project as One Zip
        </h1>
        <p className="mt-2 max-w-[65ch] text-base text-zinc-600">
          Package the compiled production bundle alongside all React, WebSocket, and Express server source files into a single clean archive.
        </p>
      </div>

      <section className="mt-8 rounded-2xl border border-zinc-200 bg-white p-6 sm:p-8">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="max-w-xl">
            <div className="flex items-center gap-2 text-sm font-semibold text-zinc-900">
              <Package className="h-4 w-4 text-blue-900" aria-hidden="true" />
              <span>chaptercraft-project-build.zip</span>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-zinc-600">
              Includes the production <span className="font-mono text-xs">dist/</span> build, <span className="font-mono text-xs">src/</span> frontend components and generated artwork, <span className="font-mono text-xs">server.ts</span> multiplayer engine, and configuration files (excluding <span className="font-mono text-xs">node_modules</span> and local secrets).
            </p>
          </div>

          <button
            type="button"
            onClick={() => void handleDownloadZip()}
            disabled={downloading}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-900 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-800 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
          >
            <Download className="h-4 w-4" aria-hidden="true" />
            {downloading ? 'Packaging Zip...' : 'Download Project (.zip)'}
          </button>
        </div>

        {errorMsg && (
          <p className="mt-4 text-sm font-medium text-red-700" role="alert">
            {errorMsg}
          </p>
        )}

        <div className="mt-8 border-t border-zinc-200 pt-6">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-sm font-semibold text-zinc-900">
              Single-Line Build &amp; Zip Command
            </h2>
            <button
              type="button"
              onClick={() => void handleCopyCommand()}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-900 hover:underline cursor-pointer"
            >
              {copiedCmd ? <Check className="h-3.5 w-3.5 text-emerald-700" /> : <Copy className="h-3.5 w-3.5" />}
              {copiedCmd ? 'Copied' : 'Copy One-Liner'}
            </button>
          </div>
          <pre className="mt-2.5 overflow-x-auto rounded-xl border border-zinc-200 bg-zinc-950 p-4 font-mono text-xs text-zinc-100">
            <code>{oneLineCommand}</code>
          </pre>
        </div>
      </section>
    </main>
  );
};
